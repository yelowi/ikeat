package aaa;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class orclogin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Windows w=new Windows("��¼",500,245,300,200);
	}

}
class Windows extends JDialog{		//û�������С���Ĵ�����JDialog
	JLabel lb1,lb2;
	JTextField tx1,tx2;
	JButton bt1,bt2;
	public Windows(String s,int a,int b,int w,int h){
		init(s);
		setBounds(a,b,w,h);
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	void init(String s){
		setTitle(s);
		Container con=getContentPane();
		con.setLayout(null);
		lb1=new JLabel("�û�����");
		lb2=new JLabel("���룺");
		lb1.setBounds(40,20,55,30);
		lb2.setBounds(40,50,40,30);
		tx1=new JTextField("aaa");
		tx1.setBounds(110,26,120,20);
		tx2=new JTextField("666");
		tx2.setBounds(110,56,120,20);
		bt1=new JButton("ȷ��");
		bt2=new JButton("����");
		bt1.setBounds(65,92,60,20);
		bt2.setBounds(155,92,60,20);
		add(lb1);
		add(lb2);
		add(tx1);
		add(tx2);
		add(bt1);
		add(bt2);
		bt1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent E){
				String name=tx1.getText().trim();
				String password=tx2.getText().trim();
				if(name.length()==0||password.length()==0){
					JOptionPane.showMessageDialog(null,"�û��������벻��Ϊ��");
					return;
				}
				if(name.equals("aaa")&&password.equals("666")){
					new orcopfirm();
					dispose();
				}
				else{
					JOptionPane.showMessageDialog(null,"�û������������");
				}
			}
		});
		bt2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent E){
				tx1.setText(null);
				tx2.setText(null);
			}
		});
	}
}
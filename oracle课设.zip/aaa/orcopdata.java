package aaa;

import java.sql.*;

public class orcopdata {
	public static String[][] Dispemp() {					//���Ա����
		
		Connection con=connorcl.getConnection();
		Statement sql;
		ResultSet rs;
		String data[][]=null;
		try {
			sql=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs=sql.executeQuery("select * from \"employee\"");
			rs.last();
			int row=rs.getRow();
			data=new String[row][8];
			rs.beforeFirst();
			int i=0;
			while(rs.next()) {
				data[i][0]=rs.getString(1);
				data[i][1]=rs.getString(2);
				data[i][2]=rs.getString(3);
				data[i][3]=rs.getString(4);
				data[i][4]=rs.getString(5);
				data[i][5]=rs.getString(6);
				data[i][6]=rs.getString(7);
				data[i][7]=rs.getString(8);
				i++;
			}
			rs.close();
			sql.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("��ѯ����");
		}
		return data;
		
	}
	public static String[][] Dispdept() {					//������ű�
		
		Connection con=connorcl.getConnection();
		Statement sql;
		ResultSet rs;
		String data[][]=null;
		try {
			sql=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs=sql.executeQuery("select * from \"department\"");
			rs.last();
			int row=rs.getRow();
			data=new String[row][4];
			rs.beforeFirst();
			int i=0;
			while(rs.next()) {
				data[i][0]=rs.getString(1);
				data[i][1]=rs.getString(2);
				data[i][2]=String.valueOf(rs.getInt(3));
				data[i][3]=rs.getString(4);
				i++;
			}
			rs.close();
			sql.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("��ѯ����");
		}
		return data;
		
	}
	public static String[][] Displev() {					//�����ټ�¼
		
		Connection con=connorcl.getConnection();
		Statement sql;
		ResultSet rs;
		String data[][]=null;
		try {
			sql=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs=sql.executeQuery("select * from \"leave\"");
			rs.last();
			int row=rs.getRow();
			data=new String[row][10];
			rs.beforeFirst();
			int i=0;
			while(rs.next()) {
				data[i][0]=rs.getString(1);
				data[i][1]=rs.getString(2);
				data[i][2]=rs.getString(3);
				data[i][3]=rs.getString(4);
				data[i][4]=String.valueOf(rs.getInt(5));
				data[i][5]=String.valueOf(rs.getDate(6));
				data[i][6]=String.valueOf(rs.getDate(7));
				data[i][7]=String.valueOf(rs.getDate(8));
				data[i][8]=rs.getString(9);
				data[i][9]=rs.getString(10);
				i++;
			}
			rs.close();
			sql.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("��ѯ����");
		}
		return data;
		
	}
	public static String[][] Dispafd() {					//���ȱ�ڼ�¼
		
		Connection con=connorcl.getConnection();
		Statement sql;
		ResultSet rs;
		String data[][]=null;
		try {
			sql=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs=sql.executeQuery("select * from \"afd\"");
			rs.last();
			int row=rs.getRow();
			data=new String[row][5];
			rs.beforeFirst();
			int i=0;		
			while(rs.next()) {
				data[i][0]=rs.getString(1);
				data[i][1]=rs.getString(2);
				data[i][2]=rs.getString(3);
				data[i][3]=String.valueOf(rs.getDate(4));
				data[i][4]=rs.getString(5);
				i++;
			}
			rs.close();
			sql.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("��ѯ����");
		}
		return data;
		
	}
	public static String[][] Dispsal() {					//������ʱ�
		
		Connection con=connorcl.getConnection();
		Statement sql;
		ResultSet rs;
		String data[][]=null;
		try {
			sql=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs=sql.executeQuery("select * from \"salary\"");
			rs.last();
			int row=rs.getRow();
			data=new String[row][6];
			rs.beforeFirst();
			int i=0;
			while(rs.next()) {
				data[i][0]=rs.getString(1);
				data[i][1]=rs.getString(2);
				data[i][2]=rs.getString(3);
				data[i][3]=String.valueOf(rs.getInt(4));
				data[i][4]=String.valueOf(rs.getInt(5));
				data[i][5]=String.valueOf(rs.getDate(6));
				i++;
			}
			rs.close();
			sql.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("��ѯ����");
		}
		return data;
		
	}
	public static String[][] Dispbt() {					//��������
		
		Connection con=connorcl.getConnection();
		Statement sql;
		ResultSet rs;
		String data[][]=null;
		try {
			sql=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs=sql.executeQuery("select * from \"bustra\"");
			rs.last();
			int row=rs.getRow();
			data=new String[row][10];
			rs.beforeFirst();
			int i=0;
			while(rs.next()) {
				data[i][0]=rs.getString(1);
				data[i][1]=rs.getString(2);
				data[i][2]=rs.getString(3);
				data[i][3]=rs.getString(4);
				data[i][4]=rs.getString(5);
				data[i][5]=String.valueOf(rs.getInt(6));
				data[i][6]=String.valueOf(rs.getDate(7));
				data[i][7]=String.valueOf(rs.getDate(8));
				data[i][8]=rs.getString(9);
				data[i][9]=rs.getString(10);
				i++;
			}
			rs.close();
			sql.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("��ѯ����");
		}
		return data;
		
	}
	public static String[][] Dispproj() {					//�����Ŀ��
		
		Connection con=connorcl.getConnection();
		Statement sql;
		ResultSet rs;
		String data[][]=null;
		try {
			sql=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs=sql.executeQuery("select * from \"project\"");
			rs.last();
			int row=rs.getRow();
			data=new String[row][4];
			rs.beforeFirst();
			int i=0;
			while(rs.next()) {
				data[i][0]=rs.getString(1);
				data[i][1]=rs.getString(2);
				data[i][2]=String.valueOf(rs.getDate(3));
				data[i][3]=String.valueOf(rs.getDate(4));
				i++;
			}
			rs.close();
			sql.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("��ѯ����");
		}
		return data;
		
	}
	public static String[][] Dispempro() {					//���Ա����Ŀ��ϵ��
		
		Connection con=connorcl.getConnection();
		Statement sql;
		ResultSet rs;
		String data[][]=null;
		try {
			sql=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs=sql.executeQuery("select * from \"emproj\"");
			rs.last();
			int row=rs.getRow();
			data=new String[row][3];
			rs.beforeFirst();
			int i=0;
			while(rs.next()) {
				data[i][0]=rs.getString(1);
				data[i][1]=rs.getString(2);
				data[i][2]=rs.getString(3);
				i++;
			}
			rs.close();
			sql.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("��ѯ����");
		}
		return data;
		
	}
	
	public int Del(String empno) {				//���ݹ���ɾ�����ݣ�Ա���������ʱ�����ĿԱ����ϵ����
		int d=-1;
		Connection con=connorcl.getConnection();	
		try {
			PreparedStatement pste=con.prepareStatement("delete from \"employee\" where empno=?");
			pste.setString(1,empno);
			d=pste.executeUpdate();
			PreparedStatement psts=con.prepareStatement("delete from \"salary\" where empno=?");
			psts.setString(1,empno);
			d=psts.executeUpdate();
			PreparedStatement pstep=con.prepareStatement("delete from \"emproj\" where empno=?");
			pstep.setString(1,empno);
			d=pstep.executeUpdate();
			pste.close();
			psts.close();
			pstep.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("ɾ��ʧ��");
		}
		return d;
			
	}
	
	public int Addemp(String empno,String ename,String sex,String id_num,String phone,String email,String post,String deptno) {		//Ա��������
		int a=-1;
		Connection con=connorcl.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement("insert into \"employee\" values(?,?,?,?,?,?,?,?)");
			pst.setString(1, empno);
			pst.setString(2, ename);
			pst.setString(3, sex);
			pst.setString(4, id_num);
			pst.setString(5, phone);
			pst.setString(6, email);
			pst.setString(7, post);
			pst.setString(8, deptno);
			a=pst.executeUpdate();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("���ӳ���");
		}
		return a;
		
	}
	public int Addproj(String prono,String proname) {		//��Ŀ������
		int a=-1;
		Connection con=connorcl.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement("insert into \"project\" values(?,?,?,?)");
			pst.setString(1, prono);
			pst.setString(2, proname);
			pst.setDate(3, new Date(1111-12-11));
			pst.setDate(4,new Date(1212-11-12));
			a=pst.executeUpdate();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("���ӳ���");
		}
		return a;
		
	}
	public int Addsal(String salno,String empno,String ename,int bsal,int dsal) {		//���ʱ�����
		int a=-1;
		Connection con=connorcl.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement("insert into \"salary\" values(?,?,?,?,?,?)");
			pst.setString(1, salno);
			pst.setString(2, empno);
			pst.setString(3, ename);
			pst.setInt(4, bsal);
			pst.setInt(5, dsal);
			pst.setDate(6, new Date(2022-12-2));System.out.println("11");
			a=pst.executeUpdate();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("���ӳ���");
		}
		return a;
		
	}
	
	public int Updateemp(String empno,String ename,String sex,String id_num,String phone,String email,String post,String deptno) {		//Ա�����޸�
		int u=-1;
		Connection con=connorcl.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement("update \"employee\" set ename=?,sex=?,id_num=?,phone=?,e-mail=?,post=?,deptno=? where empno=?");
			pst.setString(8, empno);
			pst.setString(1, ename);
			pst.setString(2, sex);
			pst.setString(3, id_num);
			pst.setString(4, phone);
			pst.setString(5, email);
			pst.setString(6, post);
			pst.setString(7, deptno);
			u=pst.executeUpdate();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("�޸�ʧ��");
		}
		return u;
	}
	public int Updatedept(String deptno,int num,String empno) {		//���ű��޸�
		int u=-1;
		Connection con=connorcl.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement("update \"department\" set num=?,empno=? where deptno=?");
			pst.setInt(1, num);
			pst.setString(2, empno);
			pst.setString(3, deptno);
			u=pst.executeUpdate();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("�޸�ʧ��");
		}
		return u;
	}

	public static String[] Que(String empno){		//���ݹ��Ų�ѯ������Ϣ������
		String data[]=new String[4];
		Connection con=connorcl.getConnection();
		ResultSet rse,rss;
		try {
			PreparedStatement pste=con.prepareStatement("select * from \"employee\" where empno=?");
			pste.setString(1, empno);
			rse=pste.executeQuery();
			if(rse.next()) {
				data[0]=rse.getString(1);
				data[1]=rse.getString(2);
				data[2]=rse.getString(3);
				data[3]=rse.getString(4);
				data[4]=rse.getString(5);
				data[5]=rse.getString(6);
				data[6]=rse.getString(7);
				data[7]=rse.getString(8);
			}else {
				data=null;
			}
			/*PreparedStatement psts=con.prepareStatement("select * from \"salary\" where empno=?");
			psts.setString(1, empno);
			rss=psts.executeQuery();
			if(rss.next()) {
				data[0]=rss.getString(1);
				data[1]=rss.getString(2);
				data[2]=rss.getString(3);
				data[3]=String.valueOf(rse.getInt(4));
				data[4]=String.valueOf(rse.getInt(5));
				data[5]=String.valueOf(rse.getDate(6));
			}else {
				data=null;
			}
			rss.close();*/
			rse.close();
			pste.close();
			//psts.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("��ѯ����");
		}
		
		return data;
	}
	
	
}
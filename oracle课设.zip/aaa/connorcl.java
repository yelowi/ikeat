package aaa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class connorcl {

	private final static String DriverClass="oracle.jdbc.driver.OracleDriver";
	private final static String url="jdbc:oracle:thin:@localhost:1521:orcl";
	private final static String user="aaa";
	private final static String password="666";
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(DriverClass);
			con = DriverManager.getConnection(
				url, user, password);
			System.out.println("��ȡ�����ɹ�!");
		} catch (Exception e) {
			System.out.println("���ݿ������򲻿���");
		}
		return con;
	}
}

package aaa;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class quefirm extends JDialog implements ActionListener{//
	JButton bt;
	JLabel lb;
	JTextField tx;
	JTextArea ta;
	public quefirm() {	//
	
		setTitle("��������");
		setBounds(450,300,400,400);
		setVisible(true);
		validate();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLayout(null);
		lb=new JLabel("���ݹ��Ų�ѯ");
		lb.setBounds(155,15,80,25);
		tx=new JTextField();
		tx.setBounds(135,55,120,20);
		ta=new JTextArea(/*"�·�\t����\t֧��\t����"*/);
		ta.setBounds(20,110,350,245);
		bt=new JButton("ȷ��");
		bt.setBounds(165,82,60,20);
		Font f=new Font("΢���ź�",Font.PLAIN,12);
		ta.setFont(f);
		add(ta);
		add(lb);
		add(tx);
		add(bt);
		bt.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==bt) {
			String mon=tx.getText().trim();
			String a[];
			a=orcopdata.Que(mon);
			if(a==null) {
				ta.append("\n");
				ta.append("�޶�Ӧ��¼����������");
			}else {
				ta.append("\n");
				ta.append(a[0]);
				ta.append("\t");
				ta.append(a[1]);
				ta.append("\t");
				ta.append(a[2]);
				ta.append("\t");
				ta.append(a[3]);
				ta.append("\t");
				ta.append(a[4]);
				ta.append("\t");
				ta.append(a[5]);
				ta.append("\t");
				ta.append(a[6]);
				ta.append("\t");
				ta.append(a[7]);
			}
		}
	}
}
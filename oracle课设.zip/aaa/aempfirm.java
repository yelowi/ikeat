package aaa;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class aempfirm extends JDialog implements ActionListener{				
	JLabel lb1,lb2,lb3,lb4,lb5,lb6,lb7,lb8;
	JTextField tx1,tx2,tx3,tx4,tx5,tx6,tx7,tx8;
	JButton bt1,bt2;
	public aempfirm() {
		setTitle("��������");
		setBounds(525,300,350,250);
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLayout(null);
		lb1=new JLabel("����");
		lb2=new JLabel("����");
		lb3=new JLabel("�Ա�");
		lb4=new JLabel("����֤��");
		lb5=new JLabel("��ϵ�绰");
		lb6=new JLabel("����");
		lb7=new JLabel("ְλ");
		lb8=new JLabel("���ź�");
		lb1.setBounds(30, 15, 40, 25);
		lb2.setBounds(170,15,40,25);
		lb3.setBounds(30,50,40,25);
		lb4.setBounds(170,50,40,25);
		lb5.setBounds(30, 85, 40, 25);
		lb6.setBounds(170,85,40,25);
		lb7.setBounds(30, 120, 40, 25);
		lb8.setBounds(170,120,40,25);
		tx1=new JTextField();
		tx1.setBounds(75,15,80,20);
		tx2=new JTextField();
		tx2.setBounds(215,15,80,20);
		tx3=new JTextField();
		tx4=new JTextField();
		tx3.setBounds(75,50,80,20);
		tx4.setBounds(215,50,80,20);
		tx5=new JTextField();
		tx6=new JTextField();
		tx5.setBounds(75,85,80,20);
		tx6.setBounds(215,85,80,20);
		tx7=new JTextField();
		tx8=new JTextField();
		tx7.setBounds(75,120,80,20);
		tx8.setBounds(215,120,80,20);
		bt1=new JButton("ȷ��");
		bt1.setBounds(90,160,60,20);
		bt1.addActionListener(this);
		bt2=new JButton("ȡ��");
		bt2.setBounds(180,160,60,20);
		bt2.addActionListener(this);
		add(lb1);
		add(lb2);
		add(lb3);
		add(lb4);
		add(lb5);
		add(lb6);
		add(lb7);
		add(lb8);
		add(tx1);
		add(tx2);
		add(tx3);
		add(tx4);
		add(tx5);
		add(tx6);
		add(tx7);
		add(tx8);
		add(bt1);
		add(bt2);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==bt1) {
			String empno=tx1.getText();
			String ename=tx2.getText();
			String sex=tx3.getText();
			String id_num=tx4.getText();
			String phone=tx5.getText();
			String email=tx6.getText();
			String post=tx7.getText();
			String deptno=tx8.getText();
			orcopdata op=new orcopdata();
			int a=op.Addemp(empno,ename,sex,id_num,phone,email,post,deptno);
			if(a>0) 
				JOptionPane.showMessageDialog(this, "���ӳɹ���");
			else 
	    		JOptionPane.showMessageDialog(this, "����ʧ�ܣ�");
				
		}
		else if(e.getSource()==bt2) {
			dispose();
		}
	}
}
package aaa;

import java.awt.BorderLayout;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class dempfirm extends JFrame {	
	
	public dempfirm() {
	String title[]={"����","����","�Ա�","����֤��","��ϵ�绰","����","ְλ","���ź�"};
	String a[][];
	a=orcopdata.Dispemp();
	JTable tb;
		setTitle("ȫ������");
		setBounds(450,300,400,400);
		setVisible(true);
		validate();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		tb=new JTable(a,title) {
			public boolean isCellEditable(int row, int column) {
			return false;        
			}
		};
		tb.setRowHeight(tb.getRowHeight()+10);
		Font f=new Font("΢���ź�",Font.PLAIN,15);
		tb.setFont(f);
		add(new JScrollPane(tb),BorderLayout.CENTER);
	}

}
package aaa;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class orcopfirm extends JFrame implements ActionListener{

	JMenuBar bar;
	JMenu me1,me2;
	JMenuItem iadd,idel,iupd,idip,ique,ipos;
	public orcopfirm(){
		setTitle("���¹���ϵͳ");
		setBounds(450,225,300,300);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		bar=new JMenuBar();
		me1=new JMenu("���ݹ���");
		me2=new JMenu("���ݲ�ѯ");
		iadd=new JMenuItem("��������");
		idel=new JMenuItem("ɾ������");
		iupd=new JMenuItem("�޸�����");
		ique=new JMenuItem("��ѯ����");
		idip=new JMenuItem("�������");
		me1.add(iadd);
		me1.add(idel);
		me1.add(iupd);
		me2.add(ique);
		me2.add(idip);
		bar.add(me1);
		bar.add(me2);
		setJMenuBar(bar);
		iadd.addActionListener(this);
		idel.addActionListener(this);
		iupd.addActionListener(this);
		ique.addActionListener(this);
		idip.addActionListener(this);
		
	}
	public void actionPerformed(ActionEvent e) {
		Object ob=e.getSource();
		if(ob==iadd) {
			new addfirm();
		}else if(ob==idel) {
			new delfirm();
		}else if(ob==iupd) {
			new updfirm();
		}else if(ob==idip) {
			new dipfirm();
		}else if(ob==ique) {
			new quefirm();
		}		
	}
}
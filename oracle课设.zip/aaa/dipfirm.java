package aaa;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class dipfirm extends JFrame implements ActionListener{		//�������������

	JMenuBar bar;
	JMenu me1,me2;
	JMenuItem dep,emp,sal,pro,lev,bus,afd,epj;
	public dipfirm(){
		setTitle("�������");
		setBounds(450,225,300,300);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		bar=new JMenuBar();
		me1=new JMenu("�������1");
		emp=new JMenuItem("Ա����");
		sal=new JMenuItem("���ʱ�");
		dep=new JMenuItem("���ű�");
		pro=new JMenuItem("��Ŀ��");
		me2=new JMenu("�������2");
		lev=new JMenuItem("��ټ�¼");
		afd=new JMenuItem("ȱ�ڼ�¼");
		bus=new JMenuItem("�����¼");
		epj=new JMenuItem("��Ŀ����");
		me1.add(lev);
		me1.add(sal);
		me1.add(dep);
		me1.add(emp);
		me2.add(lev);
		me2.add(afd);
		me2.add(bus);
		me2.add(epj);
		bar.add(me1);
		bar.add(me2);
		setJMenuBar(bar);
		lev.addActionListener(this);
		sal.addActionListener(this);
		dep.addActionListener(this);
		bus.addActionListener(this);
		emp.addActionListener(this);
		epj.addActionListener(this);
		pro.addActionListener(this);
		afd.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e) {    //���ݰ�ť�򿪽���
		Object ob=e.getSource();
		if(ob==lev) {
			new dlevfirm();
		}else if(ob==sal) {
			new dsalfirm();
		}else if(ob==dep) {
			new ddepfirm();
		}else if(ob==bus) {
			new dbusfirm();
		}else if(ob==emp) {
			new dempfirm();
		}else if(ob==epj) {
			new depjfirm();
		}else if(ob==pro) {
			new dprofirm();
		}else if(ob==afd) {
			new dafdfirm();
		}						
	}			
}
package aaa;

import java.awt.event.*;
import javax.swing.*;

public class asalfirm extends JDialog implements ActionListener{				
	JLabel lb1,lb2,lb3,lb4,lb5,lb6;
	JTextField tx1,tx2,tx3,tx4,tx5,tx6;
	JButton bt1,bt2;
	public asalfirm() {
		setTitle("���Ӽ�¼");
		setBounds(525,300,350,200);
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLayout(null);
		lb1=new JLabel("���ɱ��");
		lb2=new JLabel("����");
		lb3=new JLabel("����");
		lb4=new JLabel("��������");
		lb5=new JLabel("����");
		lb6=new JLabel("��������");
		lb1.setBounds(30, 15, 40, 25);
		lb2.setBounds(170,15,40,25);
		lb3.setBounds(30,50,40,25);
		lb4.setBounds(170,50,40,25);
		lb5.setBounds(30, 85, 40, 25);
		lb6.setBounds(170,85,40,25);
		tx1=new JTextField();
		tx1.setBounds(75,15,80,20);
		tx2=new JTextField();
		tx2.setBounds(215,15,80,20);
		tx3=new JTextField();
		tx4=new JTextField();
		tx3.setBounds(75,50,80,20);
		tx4.setBounds(215,50,80,20);
		tx5=new JTextField();
		tx6=new JTextField("2022-12-2");
		tx5.setBounds(75,85,80,20);
		tx6.setBounds(215,85,80,20);
		bt1=new JButton("ȷ��");
		bt1.setBounds(90,120,60,20);
		bt1.addActionListener(this);
		bt2=new JButton("ȡ��");
		bt2.setBounds(180,120,60,20);
		bt2.addActionListener(this);
		add(lb1);
		add(lb2);
		add(lb3);
		add(lb4);
		add(lb5);
		add(lb6);
		add(tx1);
		add(tx2);
		add(tx3);
		add(tx4);
		add(tx5);
		add(tx6);
		add(bt1);
		add(bt2);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==bt1) {
			String salno=tx1.getText();
			String empno=tx2.getText();
			String ename=tx3.getText();
			int bsal=Integer.parseInt(tx4.getText());
			int dsal=Integer.parseInt(tx5.getText());
			orcopdata op=new orcopdata();
			int a=op.Addsal(salno,empno,ename,bsal,dsal);
			if(a>0) 
				JOptionPane.showMessageDialog(this, "���ӳɹ���");
			else 
	    		JOptionPane.showMessageDialog(this, "����ʧ�ܣ�");
				
		}
		else if(e.getSource()==bt2) {
			dispose();
		}
	}
}
package aaa;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class dafdfirm extends JFrame {	
	
	public dafdfirm() {
	String title[]={"ȱ�ڼ�¼��","����","����","ȱ������","��ϵ�绰"};
	String a[][];
	a=orcopdata.Dispafd();
	JTable tb;
		setTitle("ȫ������");
		setBounds(450,300,400,400);
		setVisible(true);
		validate();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		tb=new JTable(a,title) {
			public boolean isCellEditable(int row, int column) {
			return false;        
			}
		};
		tb.setRowHeight(tb.getRowHeight()+10);
		Font f=new Font("΢���ź�",Font.PLAIN,15);
		tb.setFont(f);
		add(new JScrollPane(tb),BorderLayout.CENTER);
	}

}

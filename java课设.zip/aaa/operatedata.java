package aaa;

import java.sql.*;
import java.util.HashMap;

public class operatedata {

	public static String[][] Disp() {					//���ȫ����¼
		
		Connection con=connect.getConnection();
		Statement sql;
		ResultSet rs;
		String data[][]=null;
		try {
			sql=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs=sql.executeQuery("select * from salary");
			rs.last();
			int row=rs.getRow();
			data=new String[row][4];
			rs.beforeFirst();
			int i=0;
			while(rs.next()) {
				data[i][0]=rs.getString("month");
				data[i][1]=String.valueOf(rs.getDouble("income"));
				data[i][2]=String.valueOf(rs.getDouble("outcome"));
				data[i][3]=String.valueOf(rs.getDouble("extra"));
				i++;
			}
			rs.close();
			sql.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("��ѯ����");
		}
		return data;
		
	}
	public int Del(String mon) {				//ɾ��
		int d=-1;
		Connection con=connect.getConnection();	
		try {
			PreparedStatement pst=con.prepareStatement("delete from salary where month=?");
			pst.setString(1,mon);
			d=pst.executeUpdate();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("ɾ��ʧ��");
		}
		return d;
			
	}
	public int Add(String mon,double inc,double outc,double ext) {		//����
		int a=-1;
		Connection con=connect.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement("insert into salary values(?,?,?,?)");
			pst.setString(1, mon);
			pst.setDouble(2, inc);
			pst.setDouble(3, outc);
			pst.setDouble(4, ext);
			a=pst.executeUpdate();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("���ӳ���");
		}
		return a;
		
	}
	public int Update(String mon,double inc,double outc,double ext) {		//�޸ļ�¼
		int u=-1;
		Connection con=connect.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement("update salary set income=?,outcome=?,extra=? where month=?");
			pst.setDouble(1, inc);
			pst.setDouble(2, outc);
			pst.setDouble(3, ext);
			pst.setString(4, mon);
			u=pst.executeUpdate();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("�޸�ʧ��");
		}
		return u;
	}
	public static String[] Que(String mon){		//�����·ݲ�ѯ
		String data[]=new String[4];
		Connection con=connect.getConnection();
		ResultSet rs;
		try {
			PreparedStatement pst=con.prepareStatement("select * from salary where month=?");
			pst.setString(1, mon);
			rs=pst.executeQuery();
			if(rs.next()) {
				data[0]=rs.getString(1);
				data[1]=String.valueOf(rs.getDouble(2));
				data[2]=String.valueOf(rs.getDouble(3));
				data[3]=String.valueOf(rs.getDouble(4));
			}else {
				data=null;
			}
			rs.close();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("��ѯ����");
		}
		
		return data;
	}
	public static String[] quemoney() { 		//��ѯÿ�½���
		Connection con=connect.getConnection();
		Statement sql;
		ResultSet rs;
		String temp[]=null;
		try {
			sql=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs=sql.executeQuery("select extra from salary");
			rs.last();
			int row=rs.getRow();
			temp=new String[row];
			rs.beforeFirst();
			int i=0;
			while(rs.next()) {
				temp[i]=String.valueOf(rs.getDouble("extra"));
				i++;
			}
			rs.close();
			sql.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("��ѯ����");
		}
		return temp;
	}
	public static int sum(String data[]) {		//���㲢���´����Ŀ
		int a=-1;
		double sum=0;
		Connection con=connect.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement("update sum set deposit=? where date='now'");
			for(int i=0;i<data.length;i++) {	
				sum=sum+Double.parseDouble(data[i]);
			}
			pst.setDouble(1,sum);
			a=pst.executeUpdate();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("��������");
		}
		return a;
	}
	public static double dipsum() { 		//��ѯ�ܴ��
		Connection con=connect.getConnection();
		Statement sql;
		ResultSet rs;
		double s=0;
		try {
			sql=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs=sql.executeQuery("select * from sum");
			while(rs.next()) {
				s=rs.getDouble(1);
			}
			rs.close();
			sql.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("��ʾ����");
		}
		return s;
	}
}

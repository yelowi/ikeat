package aaa;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class user {
	
	public static boolean isRight(String n,String p) {
		String name=null;
		String password=null;
		Connection con=connect.getConnection();
		Statement sql;
		ResultSet rs;
		try {
			sql=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs=sql.executeQuery("select * from user");
			while(rs.next()) {
				name=rs.getString(1);
				password=rs.getString(2);
			}
	
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("��ѯ����");
		}
		if(name.equals(n)&&password.equals(p)) {
			return true;
		}else {
			return false;
		}
	
		
	}
	
}

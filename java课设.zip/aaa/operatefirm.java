package aaa;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class operatefirm extends JFrame implements ActionListener{

	JMenuBar bar;
	JMenu me1,me2;
	JMenuItem iadd,idel,iupd,idip,ique,ipos;
	public operatefirm(){
		setTitle("����֧����¼");
		setBounds(450,225,300,300);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		bar=new JMenuBar();
		me1=new JMenu("��¼����");
		me2=new JMenu("������¼");
		ipos=new JMenuItem("����ѯ");
		iadd=new JMenuItem("���Ӽ�¼");
		idel=new JMenuItem("ɾ����¼");
		iupd=new JMenuItem("�޸ļ�¼");
		ique=new JMenuItem("��ѯ��¼");
		idip=new JMenuItem("�����¼");
		me1.add(iadd);
		me1.add(idel);
		me1.add(iupd);
		me2.add(ique);
		me2.add(idip);
		me2.add(ipos);
		bar.add(me1);
		bar.add(me2);
		setJMenuBar(bar);
		iadd.addActionListener(this);
		idel.addActionListener(this);
		iupd.addActionListener(this);
		ique.addActionListener(this);
		idip.addActionListener(this);
		ipos.addActionListener(this);
		
	}
	public void actionPerformed(ActionEvent e) {
		Object ob=e.getSource();
		if(ob==iadd) {
			new adddata();
		}else if(ob==idel) {
			new deldata();
		}else if(ob==iupd) {
			new upddata();
		}else if(ob==idip) {
			new dipdata();
		}else if(ob==ique) {
			new quedata();
		}else if(ob==ipos) {
			new dipofirm();
		}
			
	}
}


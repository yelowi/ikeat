package aaa;

import java.sql.Connection;
import java.sql.DriverManager;

public class connect {
	private final static String DriverClass="com.mysql.cj.jdbc.Driver";
	private final static String url="jdbc:mysql://localhost:3306/aaa?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
	private final static String user="root";
	private final static String password="666";
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(DriverClass);
			con = DriverManager.getConnection(
				url, user, password);
		} catch (Exception e) {
			System.out.println("���ݿ������򲻿���");
		}
		return con;
	}
	
}
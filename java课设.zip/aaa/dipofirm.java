package aaa;

import javax.swing.*;

public class dipofirm extends JDialog{
	JTextField tf;
	JLabel lb;
	public dipofirm() {
		setTitle("�������");
		setBounds(525,300,250,200);
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLayout(null);
		lb=new JLabel("���д��");
		tf=new JTextField();
		lb.setBounds(94,40,75,30);
		tf.setBounds(68,70,100,20);
		int s=operatedata.sum(operatedata.quemoney());
		double sum=operatedata.dipsum();
		tf.setText(String.valueOf(sum));
		tf.setEditable(false);
		add(lb);
		add(tf);	
	}
}

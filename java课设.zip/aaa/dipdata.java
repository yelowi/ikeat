package aaa;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class dipdata extends JFrame {	
	
	public dipdata() {
	String title[]={"�·�","����","֧��","����"};
	String a[][];
	a=operatedata.Disp();
	JTable tb;
		setTitle("ȫ����¼");
		setBounds(450,300,400,400);
		setVisible(true);
		validate();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		tb=new JTable(a,title) {
			public boolean isCellEditable(int row, int column) {
			return false;        
			}
		};
		tb.setRowHeight(tb.getRowHeight()+10);
		Font f=new Font("΢���ź�",Font.PLAIN,15);
		tb.setFont(f);
		add(new JScrollPane(tb),BorderLayout.CENTER);
	}

}

package shiyan;

import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;

public class sss {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WinTree wt=new WinTree("�����",550,450,400,300);
	}

}
class WinTree extends JFrame implements TreeSelectionListener{
	JTree tr;
	JTextArea showText;
	WinTree(String s,int a,int b,int w,int h){
		init(s);
		setBounds(a,b,w,h);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	void init(String s){
		setLayout(new GridLayout(1,2));
		DefaultMutableTreeNode root=new DefaultMutableTreeNode("ͬѧ¼");
		DefaultMutableTreeNode ndp=new DefaultMutableTreeNode("Сѧͬѧ");
		DefaultMutableTreeNode ndu=new DefaultMutableTreeNode("��ѧͬѧ");
		DefaultMutableTreeNode ndm=new DefaultMutableTreeNode("��ѧͬѧ");
		DefaultMutableTreeNode p1=new DefaultMutableTreeNode(new Person("����","11111111111","xxxxxx@121.net"));
		DefaultMutableTreeNode u1=new DefaultMutableTreeNode(new Person("����","22222222222","xyxxxx@122.net"));
		DefaultMutableTreeNode u2=new DefaultMutableTreeNode(new Person("��С��","33333333333","yyxxxa@aax.net"));
		DefaultMutableTreeNode m1=new DefaultMutableTreeNode(new Person("�","44444444444","aasxwd@111.net"));
		DefaultMutableTreeNode p2=new DefaultMutableTreeNode(new Person("��С��","55555555555","asdxxf@456.net"));
		DefaultMutableTreeNode m2=new DefaultMutableTreeNode(new Person("��÷÷","66666666666","dsssss@add.net"));
		root.add(ndp);
		root.add(ndm);
		root.add(ndu);
		ndp.add(p1);
		ndp.add(p2);
		ndu.add(u1);
		ndu.add(u2);
		ndm.add(m1);
		ndm.add(m2);
		tr=new JTree(root);
		tr.addTreeSelectionListener(this);
		showText=new JTextArea();
		add(new JScrollPane(tr));
		add(new JScrollPane(showText));
		Font f=new Font("΢���ź�",Font.PLAIN,16);
		showText.setFont(f);
		validate();	
		
	}
	public void valueChanged(TreeSelectionEvent e) {
		DefaultMutableTreeNode node=(DefaultMutableTreeNode)tr.getLastSelectedPathComponent();
		if(node==null)
			return;
		if(node.isLeaf()){
			Person p=(Person)node.getUserObject();
			showText.append("\n"+p.name+"\n�绰��"+p.number+"\n���䣺"+p.mail);
		}
		else{
			showText.setText(null);
		}
	}
}  
class Person{
	String name,number,mail;
	Person(String n1,String n2,String m){
		name=n1;
		number=n2;
		mail=m;
	}
	public String toString(){
		return name;
	}
}

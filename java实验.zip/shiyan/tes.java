package shiyan;

import javax.swing.*;
import java.awt.*;

public class tes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Win win=new Win("1111",500,200,500,500);
		
		
	}
	
}
class Win extends JFrame{
	JMenuBar bar;
	JMenu me1,me2,me3,it4;
	JMenuItem it1,it2,it3;
	JCheckBox cb;
	JRadioButton rb1,rb2;
	ButtonGroup group;
	Icon ic1,ic2,ic3;
	public Win(String s,int a,int b,int w,int h){
		init(s);
		setBounds(a, b, w, h);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	void init(String s){
		setTitle(s);
		ic1=new ImageIcon("src/img/cut1.png");
		ic2=new ImageIcon("src/img/copy1.png");
		ic3=new ImageIcon("src/img/ppp.png");
		bar=new JMenuBar();
		me1=new JMenu("File");
		me2=new JMenu("Edit");
		me3=new JMenu("Help");
		it1=new JMenuItem("Cut");
		it2=new JMenuItem("Copy");
		it3=new JMenuItem("Paste");
		it4=new JMenu("Options");
		cb=new JCheckBox("Read-only");
		rb1=new JRadioButton("Insert");
		rb2=new JRadioButton("Overtype");
		it1.setIcon(ic1);
		it2.setIcon(ic2);
		it3.setIcon(ic3);
		group=new ButtonGroup();
		group.add(rb1);
		group.add(rb2);
		me2.add(it1);
		me2.add(it2);
		me2.add(it3);
		me2.addSeparator();
		me2.add(it4);
		it4.add(cb);
		it4.addSeparator();
		it4.add(rb1);
		it4.add(rb2);
		bar.add(me1);
		bar.add(me2);
		bar.add(me3);
		setJMenuBar(bar);
	}
}
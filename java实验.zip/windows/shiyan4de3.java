package windows;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class shiyan4de3 {

	public static void main(String[] args) {
		
		Win win=new Win("�����ת��Ϊ��Ԫ",575,255,300,200);
		
	}
		
}
class Win extends JFrame{
		JLabel lb1,lb2,lb3;
		JTextField f1,f2;
		JButton bt;
		PoliceListener listener;
		public Win(String s,int a,int b,int w,int h){
			init(s);
			setBounds(a,b,w,h);
			setVisible(true);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}
		void init(String s){
			setTitle(s);
			setLayout(null);
			lb1=new JLabel("�����/Ԫ��");
			lb2=new JLabel("��Ԫ/dollar��");
			lb3=new JLabel("�����ʣ�6.17��");
			lb1.setBounds(10,5,65,35);
			lb2.setBounds(10,30,75,35);
			lb3.setBounds(30,68,90,35);
			f1=new JTextField();
			f2=new JTextField();
			f1.setBounds(90,12,180,20);
			f2.setBounds(90,38,180,20);
			bt=new JButton("ת��");
			bt.setBounds(155,71,65,25);
			listener=new PoliceListener();
			listener.setView(this);
			f1.addActionListener(listener);
			bt.addActionListener(listener);
			add(lb1);
			add(lb2);
			add(lb3);
			add(f1);
			add(f2);
			add(bt);
		}
	}
class PoliceListener implements ActionListener{
	Win view;
	void setView(Win view) {
		this.view=view;
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==view.bt) {
			String s=view.f1.getText();
			double d=Double.parseDouble(s);
			view.f2.setText(String.valueOf(d/6.17));
		}
	}
}
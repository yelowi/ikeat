package windows;

import java.awt.Color;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.KeyStroke;

class MenuDemo extends JFrame{
   JMenuBar bar;
   JMenu menuFile;
   JMenuItem itemRed,itemYellow;
   JRadioButtonMenuItem rbMenu1,rbMenu2;
   JCheckBoxMenuItem jcbMenu1,jcbMenu2;
	public MenuDemo() {
		super("�˵�ʾ��");
		bar=new JMenuBar();
		menuFile=new JMenu("�ļ�");
		
		itemRed=new JMenuItem("���ú�ɫ����");
		itemRed.setAccelerator(KeyStroke.getKeyStroke("alt R"));  //���ÿ�ݼ�
		
		itemYellow=new JMenuItem("���û�ɫ����");
		itemYellow.setAccelerator(KeyStroke.getKeyStroke("alt Y"));//���ÿ�ݼ�
		
		 rbMenu1=new JRadioButtonMenuItem("��ѡ�˵�1");
		 rbMenu2=new JRadioButtonMenuItem("��ѡ�˵�2");
		 jcbMenu1=new JCheckBoxMenuItem("��ѡ��ť1");
		 jcbMenu2=new JCheckBoxMenuItem("��ѡ��ť2");
		 
		 menuFile.add(itemRed);
		 menuFile.add(itemYellow);
		 menuFile.addSeparator();
		 
		 menuFile.add(rbMenu1);
		 menuFile.add(rbMenu2);
		 ButtonGroup g=new ButtonGroup();
		 g.add(rbMenu1);
		 g.add(rbMenu2);
		 menuFile.addSeparator();
		 
		 menuFile.add(jcbMenu1);
		 menuFile.add(jcbMenu2);
		 
		 bar.add(menuFile);
		 setJMenuBar(bar);
		 setBounds(200,200,500,500);
		 
		 //���ò˵���itemRed�¼�
		 itemRed.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				getContentPane().setBackground(Color.RED);
				
			}
		});
		//���ò˵���itemYellow�¼�
		 itemYellow.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					getContentPane().setBackground(Color.YELLOW);
					
				}
			});
		 setVisible(true);
		 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	
	
}


public class E {
   public static void main (String []args)   {
    new MenuDemo();
}}
package student;

import java.awt.event.*;
import javax.swing.*;

public class delstu extends JDialog implements ActionListener{	
	JLabel lb;
	JTextField tx;
	JButton bt1,bt2;
	public delstu() {
		setTitle("ɾ����Ϣ");
		setBounds(525,300,350,180);
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLayout(null);
		lb=new JLabel("ָ��ѧ��ɾ��");
		lb.setBounds(125,15,100,25);
		tx=new JTextField();
		tx.setBounds(115,45,100,20);
		bt1=new JButton("ȷ��");
		bt1.setBounds(90,82,60,20);
		bt1.addActionListener(this);
		bt2=new JButton("ȡ��");
		bt2.setBounds(180,82,60,20);
		bt2.addActionListener(this);
		add(lb);
		add(tx);
		add(bt1);
		add(bt2);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==bt1) {
			String num=tx.getText();
			operate op=new operate();
			int d=op.Del(num);
			if(d>0) 
				JOptionPane.showMessageDialog(this, "ɾ���ɹ���");
			else 
	    		JOptionPane.showMessageDialog(this, "ɾ��ʧ�ܣ�");
				
		}
		else if(e.getSource()==bt2) {
			dispose();
		}
	}

}

package student;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class dipstu extends JFrame {	
	
	public dipstu() {
	String title[]={"ѧ��","����","�Ա�","�绰"};
	String a[][];
	a=operate.Disp();
	JTable tb;
		setTitle("ȫ��ѧ��");
		setBounds(450,300,400,400);
		setVisible(true);
		validate();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		tb=new JTable(a,title) {
			public boolean isCellEditable(int row, int column) {
			return false;        
			}
		};
		tb.setRowHeight(tb.getRowHeight()+10);
		Font f=new Font("΢���ź�",Font.PLAIN,15);
		tb.setFont(f);
		add(new JScrollPane(tb),BorderLayout.CENTER);
	}

}
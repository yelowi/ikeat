package student;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class mainfirm{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		firm f=new firm(450,225,500,500);
	}
}
class firm extends JFrame implements ActionListener{
	JMenuBar bar;
	JMenu me1,me2;
	JMenuItem iadd,idel,iupd,idip,ique;
	public firm(int a,int b,int w,int h){
		setTitle("ѧ����Ϣ����");
		setBounds(a,b,w,h);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		bar=new JMenuBar();
		me1=new JMenu("��Ϣ����");
		me2=new JMenu("ѧ����Ϣ");
		iadd=new JMenuItem("������Ϣ");
		idel=new JMenuItem("ɾ����Ϣ");
		iupd=new JMenuItem("�޸���Ϣ");
		ique=new JMenuItem("��ѯ��Ϣ");
		idip=new JMenuItem("�����Ϣ");
		me1.add(iadd);
		me1.add(idel);
		me1.add(iupd);
		me2.add(ique);
		me2.add(idip);
		bar.add(me1);
		bar.add(me2);
		setJMenuBar(bar);
		iadd.addActionListener(this);
		idel.addActionListener(this);
		iupd.addActionListener(this);
		ique.addActionListener(this);
		idip.addActionListener(this);
		
	}
	public void actionPerformed(ActionEvent e) {
		Object ob=e.getSource();
		if(ob==iadd) {
			new addstu();
		}else if(ob==idel) {
			new delstu();
		}else if(ob==iupd) {
			new updstu();
		}else if(ob==idip) {
			new dipstu();
		}else if(ob==ique) {
			new questu();
		}
			
	}
}

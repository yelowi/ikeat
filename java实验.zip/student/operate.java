package student;

import java.sql.*;
import java.util.HashMap;

public class operate {

	public static String[][] Disp() {					//���ȫ��
		
		Connection con=connect.getConnection();
		Statement sql;
		ResultSet rs;
		String data[][]=null;
		try {
			sql=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			rs=sql.executeQuery("select * from student");
			rs.last();
			int row=rs.getRow();
			data=new String[row][4];
			rs.beforeFirst();
			int i=0;
			while(rs.next()) {
				data[i][0]=rs.getString(1);
				data[i][1]=rs.getString(2);
				data[i][2]=rs.getString(3);
				data[i][3]=rs.getString(4);
				i++;
			}
			rs.close();
			sql.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("��ѯ����");
		}
		return data;
		
	}
	public int Del(String num) {				//ɾ��
		int d=-1;
		Connection con=connect.getConnection();	
		try {
			PreparedStatement pst=con.prepareStatement("delete from student where no=?");
			pst.setString(1,num);
			d=pst.executeUpdate();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("ɾ��ʧ��");
		}
		return d;
			
	}
	public int Add(String num,String name,String sex,String tel) {		//����
		int a=-1;
		Connection con=connect.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement("insert into student values(?,?,?,?)");
			pst.setString(1, num);
			pst.setString(2, name);
			pst.setString(3, sex);
			pst.setString(4, tel);
			a=pst.executeUpdate();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("���ӳ���");
		}
		return a;
		
	}
	public int Update(String num,String name,String sex,String tel) {		//�޸�
		int u=-1;
		Connection con=connect.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement("update student set name=?,gender=?,tel=? where no=?");
			pst.setString(1, name);
			pst.setString(2, sex);
			pst.setString(3, tel);
			pst.setString(4, num);
			u=pst.executeUpdate();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("�޸�ʧ��");
		}
		return u;
	}
	public static String[] Que(String num){		//����ѧ�Ų�ѯ
		String data[]=new String[4];
		Connection con=connect.getConnection();
		ResultSet rs;
		try {
			PreparedStatement pst=con.prepareStatement("select * from student where no=?");
			pst.setString(1, num);
			rs=pst.executeQuery();
			if(rs.next()) {
				data[0]=rs.getString(1);
				data[1]=rs.getString(2);
				data[2]=rs.getString(3);
				data[3]=rs.getString(4);
			}else {
				data=null;
			}
			rs.close();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("��ѯ����");
		}
		
		return data;
	}
}

package student;

import java.awt.event.*;
import javax.swing.*;

public class updstu extends JDialog implements ActionListener{				
	JLabel lb1,lb2,lb3,lb4;
	JTextField tx1,tx2,tx3,tx4;
	JButton bt1,bt2;
	public updstu(){
		setTitle("�޸���Ϣ");
		setBounds(525,300,350,180);
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLayout(null);
		lb1=new JLabel("ѧ��");
		lb2=new JLabel("����");
		lb3=new JLabel("�Ա�");
		lb4=new JLabel("�绰");
		lb1.setBounds(30, 15, 40, 25);
		lb2.setBounds(170,15,40,25);
		lb3.setBounds(30,50,40,25);
		lb4.setBounds(170,50,40,25);
		tx1=new JTextField();
		tx1.setBounds(75,15,80,20);
		tx2=new JTextField();
		tx2.setBounds(215,15,80,20);
		tx3=new JTextField();
		tx4=new JTextField();
		tx3.setBounds(75,50,80,20);
		tx4.setBounds(215,50,80,20);
		bt1=new JButton("ȷ��");
		bt1.setBounds(90,100,60,20);
		bt1.addActionListener(this);
		bt2=new JButton("ȡ��");
		bt2.setBounds(180,100,60,20);
		bt2.addActionListener(this);
		add(lb1);
		add(lb2);
		add(lb3);
		add(lb4);
		add(tx1);
		add(tx2);
		add(tx3);
		add(tx4);
		add(bt1);
		add(bt2);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==bt1) {
			String num=tx1.getText();
			String name=tx2.getText();
			String sex=tx3.getText();
			String tel=tx4.getText();
			operate op=new operate();
			int a=op.Update(num, name, sex, tel);
			if(a>0) 
				JOptionPane.showMessageDialog(this, "�޸ĳɹ���");
			else 
	    		JOptionPane.showMessageDialog(this, "�޸�ʧ�ܣ�");
				
		}
		else if(e.getSource()==bt2) {
			dispose();
		}
	}
}